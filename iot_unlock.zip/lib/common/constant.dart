class Constant {
  static const String key_guide = 'key_guide';
  static const String key_user_detail_entity = 'key_user_detail_entity';
  static const String key_user_group = 'key_user_group';
  static const String key_current_user = 'key_current_user';
  static const String base_url = "http://10.10.30.90:6106/zns/";

  static const String url_get_captcha = "captcha/public/renew";
  static const String url_login = "public/login/pc";

  static const String key_token = "key_token";
  static const String key_user_info = "key_user_info";
}
