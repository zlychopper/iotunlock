class UserEntity {
  String account;
  String name;
  String phone;
  String password;
  String icon;
  int id;

  UserEntity.fromJson(Map<String, dynamic> json)
      : account = json['account'],
        name = json['name'],
        phone = json['phone'],
        id = json['id'],
        icon = json['icon'],
        password = json['password'];

  Map<String, dynamic> toJson() => {
        'account': account,
        'name': name,
        'phone': phone,
        'password': password,
        'icon': icon,
        'id': id,
      };

  @override
  bool operator ==(other) {
    if (other.runtimeType != runtimeType) return false;
    final UserEntity typedOther = other;
    return account == typedOther.account;
  }

  @override
  int get hashCode {
    return account.hashCode;
  }

  @override
  String toString() {
    StringBuffer sb = new StringBuffer('{');
    sb.write("\"account\":\"$account\"");
    sb.write(",\"icon\":\"$icon\"");
    sb.write(",\"id\":$id");
    sb.write(",\"name\":\"$name\"");
    sb.write(",\"password\":\"$password\"");
    sb.write('}');
    return sb.toString();
  }
}

class GroupEntity {
  String name;
  List<int> users;

  GroupEntity.fromJson(Map<String, dynamic> json)
      : name = json['name'],
        users = List<int>.from(json['users']);
  Map<String, dynamic> toJson() => {
        'name': name,
        'users': users,
      };
}

class UserDetailEntity {
  UserEntity user;
  List<UserEntity> contacts;
  List<GroupEntity> groups;

  UserDetailEntity(this.user, {this.contacts, this.groups});
  factory UserDetailEntity.fromJson(Map<String, dynamic> json) {
    UserEntity u = UserEntity.fromJson(json['user']);
    List list = json["contacts"] as List;
    List<UserEntity> contacts =
        list.map((item) => UserEntity.fromJson(item)).toList();
    var groupList = json['groups'] as List;
    List<GroupEntity> groups =
        groupList.map((item) => GroupEntity.fromJson(item)).toList();
    return UserDetailEntity(u, contacts: contacts, groups: groups);
  }

  Map<String, dynamic> toJson() => {
        'user': user.toJson(),
        'contacts': contacts,
        'groups': groups,
      };
}

class DeviceEntity {
  String name;
  String icon;
  bool open;

  DeviceEntity.fromJson(Map<String, dynamic> json)
      : name = json["name"],
        icon = json["icon"],
        open = json["open"];
  Map<String, dynamic> toJson() => {
        'name': name,
        'icon': icon,
        'open': open,
      };

  @override
  String toString() {
    StringBuffer sb = new StringBuffer('{');
    sb.write("\"name\":\"$name\"");
    sb.write(",\"icon\":\"$icon\"");
    sb.write(",\"open\":$open");
    sb.write('}');
    return sb.toString();
  }
}

//class GroupEntity {
//  Map<String, List<UserEntity>> _group;
//  UserEntity _currentUser;
//  GroupEntity() {
//    _init();
//  }
//  void add(UserEntity entity) {
//    String key = _currentUser.account;
//    _add(key, entity);
//    _save();
//  }
//
//  void addAll(List<UserEntity> entities) {
//    String key = _currentUser.account;
//    entities.forEach((entity) {
//      _add(key, entity);
//    });
//    _save();
//  }
//
//  List<UserEntity> group() {
//    String key = _currentUser.account;
//    return _group[key];
//  }
//
//  void _init() {
//    UserEntity temp = SpHelper.getObject<UserEntity>(Constant.key_user_entity);
//    if (temp == null) {
//      return null;
//    }
//    _currentUser = temp;
//    _group = {};
//    Map<String, dynamic> map = SpUtil.getObject(Constant.key_user_group);
//    if (map != null) {
//      map.forEach((k, v) {
//        List list = map[k];
//        List<UserEntity> users =
//            list.map((item) => UserEntity.fromJson(item)).toList();
//        _group[k] = users;
//      });
//    }
//  }
//
//  void _add(String key, UserEntity entity) {
//    if (_group.containsKey(key)) {
//      List<UserEntity> items = _group[key];
//      if (!items.contains(entity)) {
//        items.add(entity);
//      } else {
//        int index = items.indexOf(entity);
//        items.removeAt(index);
//        items.add(entity);
//      }
//    } else {
//      _group[key] = [entity];
//    }
//  }
//
//  void _save() {
////    SpUtil.putObject(Constant.key_user_group, _group);
//    print(_group);
//    SpUtil.putObject(Constant.key_user_group, _group).then((value) {
//      if (value) {
//        print('success');
//      } else {
//        print('failed');
//      }
//    }).whenComplete(() {
//      print('complete');
//    }).catchError((error) {
//      print(error);
//    });
//  }
//
//  @override
//  String toString() {
//    return json.encode(_group);
//  }
//}
