import 'dart:convert';

import 'package:dio/dio.dart';
import 'package:iot_unlock/common/constant.dart';
import 'package:iot_unlock/data/vo/response_vo.dart';
import 'package:iot_unlock/utils/dio_util.dart';

class LoginRepository {
//  Future<Response<ResponseBody>> getCheckCode() async {
//    return await DioUtil().postStream(Constant.get_captcha);
//  }

  Future<Response<List<int>>> getCheckCode() async {
    return await DioUtil().postBytes(Constant.url_get_captcha);
  }

  Future<Map<String, dynamic>> login(Map<String, dynamic> params) async {
    String data = json.encode(params);
    ResponseVO<Map<String, dynamic>> vo =
        await DioUtil().post(Constant.url_login, data: data);
    return vo.data;
  }
}
