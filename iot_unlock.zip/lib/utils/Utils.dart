class Utils {
  static String getImgPath(String name) {
    return 'assets/images/$name';
  }
}
